package controller;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class AvatarController {


    public void putImageInAvatar(MouseEvent mouseEvent) {
        System.out.println(((ImageView)mouseEvent.getSource()).hashCode());
    }
}
