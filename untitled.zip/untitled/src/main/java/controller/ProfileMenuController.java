package controller;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import model.User;
import view.AvatarMenu;
import view.ProfileMenu;
import view.SignMenu;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;

public class ProfileMenuController {
    public TextField newThing;

    public void deleteAccount(MouseEvent mouseEvent) throws Exception {
        String content = "Your account will be delete for ever!!!";
        User.getUsers().remove(User.getLogedInUser());
        if (showAlert(content))
            goLoginMenu();


    }

    private void goLoginMenu() throws Exception {
        // chegory bargardem aghab????
         SignMenu signMenu= new SignMenu();
        signMenu.start(SignMenu.stage);
    }

    private boolean showAlert(String content) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "sadasfd", ButtonType.YES, ButtonType.CANCEL);
        alert.setContentText(content);
        alert.setHeaderText("Are you sure?????");
        alert.setTitle("");
        alert.showAndWait();
        return alert.getResult().getButtonData().equals(ButtonData.YES);
    }

    public void logOut(MouseEvent mouseEvent) throws Exception {
        if (showAlert("do you really want to log out?"))
            goLoginMenu();
    }

    public void changePass(MouseEvent mouseEvent) {
        if (showAlert("do you really want to change your password?"))
            User.getLogedInUser().setPassword(newThing.getText());
    }

    public void changeUsername(MouseEvent mouseEvent) {
        if (showAlert("do you really want to change your username?"))
            User.getLogedInUser().setUsername(newThing.getText());
    }

    public void goAvatar(MouseEvent mouseEvent) throws Exception {
        AvatarMenu avatarMenu = new AvatarMenu();
        avatarMenu.start(SignMenu.stage);
    }
}
