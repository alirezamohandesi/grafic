package controller;

import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import model.Enums;
import model.User;
import view.ProfileMenu;
import view.SignMenu;

public class SignController {

    public TextField username;
    public TextField password;

    public void chap(MouseEvent mouseEvent) {
        System.out.println("salam");
    }

    public void signUp(MouseEvent mouseEvent) throws Exception {
        if (User.getUserByUsername(username.getText()) != null) {
            showWarningAlert("username already exist", "", "Sign up failed");
            return;
        } else if (!username.getText().matches("^[a-zA-Z0-9]\\S{3,}")) {
            showWarningAlert("invalid username", "your username must have at least 4 character and start with (a-zA-Z0-9)", "Sign up failed");
            return;
        } else if (!Enums.check(password.getText(), Enums.PASSWORD)) {
            showWarningAlert("weak password", "your password must be a combination of\nuppercase letters,lowercase letters, numbers,\nand symbols and at least 8 character", "sign in failed");
            return;
        }
        User.getUsers().add(new User(username.getText(), password.getText()));
        showInfoAlert(username.getText());


    }

    private void showInfoAlert(String username1) throws Exception {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("do you want to login?");
        alert.setHeaderText("");
        alert.setTitle("Sign up was successful");
        alert.showAndWait();
        if (!alert.getResult().getButtonData().equals(ButtonBar.ButtonData.CANCEL_CLOSE))
            goProfile();


        username.clear();
        password.clear();


    }

    public static void showWarningAlert(String header, String text, String title) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setContentText(text);
        alert.setHeaderText(header);
        alert.setTitle(title);
        alert.show();
    }

    public void logIn(MouseEvent mouseEvent) throws Exception {
        User user = User.getUserByUsername(username.getText());
        if (user == null) {
            showWarningAlert("username doesn't exist", "If you Don't have an account please sign up", "Sign in failed");
            return;
        } else if (!user.getPassword().equals(password.getText())) {
            showWarningAlert("incorrect password", "", "Sign in failed");
            return;
        }

        goProfile();


    }

    private void goProfile() throws Exception {
        User user = User.getUserByUsername(username.getText());
        if (user != null)
            User.setLoggedInUser(user);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("You are logged in as " + User.getLogedInUser().getUsername());
        alert.setHeaderText("");
        alert.setTitle("Logged in successfully");
        alert.show();
        ProfileMenu profileMenu = new ProfileMenu();
        profileMenu.start(SignMenu.stage);
        username.clear();
        password.clear();
    }

    public void logInAsGuest(MouseEvent mouseEvent) throws Exception {
        if (User.getUserByUsername(username.getText()) != null) {
            showWarningAlert("username already exist", "", "login failed");
            return;
        } else if (!username.getText().matches("^[a-zA-Z0-9]\\S{3,}")) {
            showWarningAlert("invalid username", "your username must have at least 4 character and start with (a-zA-Z0-9)", "Sign up failed");
            return;
        }
        User.setLoggedInUser(new User(username.getText(), "1"));
        goProfile();
    }
}
