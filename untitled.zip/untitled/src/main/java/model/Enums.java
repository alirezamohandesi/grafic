package model;

public enum Enums {
    PASSWORD("(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])\\S{8,}");
    private String regex;
    Enums(String regex){
        this.regex = regex;
    }
    public static boolean check(String string ,Enums enums){
      return string.matches(enums.regex);
    }
}
