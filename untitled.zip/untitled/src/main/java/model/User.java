package model;

import java.util.ArrayList;
import javafx.scene.image.Image;
import view.SignMenu;

public class User {
    private Image image;
    private String username;
    private String password;
    private static User logedInUser;
    private static ArrayList<User> users =new ArrayList<>();

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        int i =password.hashCode()%3;
        this.image =new Image(SignMenu .class.getResourceAsStream("/images/avatar"+i+".png"));
    }

    public static User getUserByUsername(String username){
        for (User user: users){
            if (user.username.equals(username))
                return user;
        }
        return null;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public  static User getLogedInUser() {
        return logedInUser;
    }

    public static void  setLoggedInUser(User logedInUser) {
        User.logedInUser = logedInUser;
    }
}
