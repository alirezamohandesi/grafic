module grafic {
    requires javafx.fxml;
    requires javafx.media;
    requires javafx.controls;
    exports view;
    opens view to javafx.fxml;
    exports controller;
    opens controller to javafx.fxml;
}