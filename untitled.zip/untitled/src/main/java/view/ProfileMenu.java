package view;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.net.URL;

public class ProfileMenu {
    public void start(Stage stage) throws Exception {
        Image image = new Image(SignMenu.class.getResourceAsStream("/images/backprof.png"));
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
        URL url = SignMenu.class.getResource("/FXML/Profile.fxml");
        BorderPane root = FXMLLoader.load(url);
        root.setBackground(new Background(backgroundImage));
        Scene scene =new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
