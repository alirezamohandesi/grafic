package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import java.net.URL;


public class SignMenu extends Application {
    public static Stage stage;
    public static void main(String[] args) {
            launch(args);


      }
    @Override
    public void start(Stage stage) throws Exception {
        Image image = new Image(SignMenu.class.getResourceAsStream("/images/backsign.png"));
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
        stage.getIcons().add(new Image(SignMenu.class.getResourceAsStream("/images/backsign.png")));
        stage.setTitle("Atomic bomb game");
        URL url = SignMenu.class.getResource("/FXML/SignMenu.fxml");
        SignMenu.stage =stage;
        BorderPane root = FXMLLoader.load(url);
        root.setBackground(new Background(backgroundImage));
        Scene scene =new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}